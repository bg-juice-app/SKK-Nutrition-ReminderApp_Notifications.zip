package com.example.reminderapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Rappel"
        val channelId = "reminder_channel"
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Moment de : $title")
            .setContentText("C’est l’heure pour : $title")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        with(NotificationManagerCompat.from(context)) {
            createNotificationChannel(channelId, "Rappels", "Notifications de rappels")
            notify(title.hashCode(), notification)
        }
    }

    private fun NotificationManagerCompat.createNotificationChannel(id: String, name: String, desc: String) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = android.app.NotificationChannel(id, name, android.app.NotificationManager.IMPORTANCE_HIGH)
            ch.description = desc
            this.createNotificationChannel(ch)
        }
    }
}