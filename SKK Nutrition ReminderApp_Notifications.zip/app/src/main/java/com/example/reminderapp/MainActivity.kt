package com.example.reminderapp

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private val schedule = listOf(
        Pair(5, 30) to "Petit‑déjeuner",
        Pair(10, 0) to "Collation matin",
        Pair(12, 0) to "Déjeuner",
        Pair(15, 0) to "Goûter",
        Pair(19, 0) to "Dîner",
        Pair(21, 30) to "Collation soir",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnStart).setOnClickListener { setAlarms() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { cancelAlarms() }
    }

    private fun setAlarms() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        schedule.forEachIndexed { idx, pair ->
            val (time, title) = pair
            val (hour, min) = time
            val intent = Intent(this, ReminderReceiver::class.java).apply {
                putExtra("title", title)
            }
            val pi = PendingIntent.getBroadcast(this, idx, intent, PendingIntent.FLAG_UPDATE_CURRENT)
            val cal = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
            }
            am.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                cal.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pi
            )
        }
    }

    private fun cancelAlarms() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        schedule.indices.forEach { idx ->
            val intent = Intent(this, ReminderReceiver::class.java)
            val pi = PendingIntent.getBroadcast(this, idx, intent, PendingIntent.FLAG_UPDATE_CURRENT)
            am.cancel(pi)
        }
    }
}